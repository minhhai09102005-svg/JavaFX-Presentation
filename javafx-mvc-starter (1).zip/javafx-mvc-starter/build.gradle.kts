plugins {
    application
    id("org.openjfx.javafxplugin") version "0.0.13"
}
repositories { mavenCentral() }
java { toolchain { languageVersion.set(JavaLanguageVersion.of(21)) } }
javafx {
    version = "21"
    modules = listOf("javafx.controls","javafx.fxml")
}
application { mainClass.set("com.example.mvc.MainApp") }
