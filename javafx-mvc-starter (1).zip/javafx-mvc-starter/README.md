# JavaFX MVC Starter (files: Model, View, Controller)

## Run
- JDK 21+, Gradle 8+
```
gradle run
```
## Structure
- Model.java  : dữ liệu + logic domain (Properties để binding)
- View.fxml   : giao diện (FXML + CSS)
- Controller.java : nối View <-> Model, xử lý sự kiện
- MainApp.java: điểm vào ứng dụng (Application.start)
