rootProject.name = "javafx-mvc-starter"
