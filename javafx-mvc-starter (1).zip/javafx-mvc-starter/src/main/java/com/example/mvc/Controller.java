package com.example.mvc;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

// CONTROLLER: bắt sự kiện, nối View <-> Model
public class Controller {

  @FXML private TextField nameField;
  @FXML private Label greeting;
  @FXML private Label counterLabel;
  @FXML private Button incBtn, decBtn, resetBtn;

  private final Model model = new Model(); // thường sẽ được inject/service; demo giữ đơn giản

  @FXML
  public void initialize() {
    // Two-way: TextField <-> model.name
    nameField.textProperty().bindBidirectional(model.nameProperty());

    // One-way: greeting hiển thị theo name
    greeting.textProperty().bind(model.nameProperty().concat(", welcome!"));

    // One-way: counterLabel theo count
    counterLabel.textProperty().bind(model.countProperty().asString());

    // Sự kiện nút
    incBtn.setOnAction(e -> model.inc());
    decBtn.setOnAction(e -> model.dec());
    resetBtn.setOnAction(e -> {
      model.setName("Alice");
      while (model.getCount() > 0) model.dec();
      while (model.getCount() < 0) model.inc();
    });
  }
}
