package com.example.mvc;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

// MODEL: dữ liệu + logic domain
public class Model {
  private final StringProperty name = new SimpleStringProperty("Alice");
  private final IntegerProperty count = new SimpleIntegerProperty(0);

  public StringProperty nameProperty() { return name; }
  public IntegerProperty countProperty() { return count; }

  public String getName() { return name.get(); }
  public void setName(String n) { name.set(n); }

  public int getCount() { return count.get(); }
  public void inc() { count.set(count.get() + 1); }
  public void dec() { count.set(count.get() - 1); }
}
